In this programming assignment you will optimize a simple tracking system using Bayesian optimization with Gaussian processes. 
The same method can be used for more complex systems optimization.

Follow the instructions in **tracker.ipynb** notebook.
