#!/bin/bash

mkdir -p data/cornell
cd data/cornell
wget https://github.com/Conchylicultor/DeepQA/raw/master/data/cornell/movie_conversations.txt
wget https://github.com/Conchylicultor/DeepQA/raw/master/data/cornell/movie_lines.txt
